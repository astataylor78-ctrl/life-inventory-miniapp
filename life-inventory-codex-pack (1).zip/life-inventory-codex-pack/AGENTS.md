# AGENTS.md

## Project intent
Build a personal-use WeChat Mini Program for household item inventory, low-stock prevention, and expiry prevention.

## Source of truth
- Product requirements: `PRD.md`
- Technical constraints: `TECHNICAL_PLAN.md`
- Acceptance: `ACCEPTANCE_TESTS.md`
- Execution order: `CODEX_TASK.md`

## Mandatory rules
- Use Chinese user-facing copy.
- Do not implement out-of-scope features.
- Do not commit credentials, AppID, CloudBase environment IDs, openid, or personal data.
- Keep inventory writes server-side and transactional.
- Every stock change must create a transaction record.
- Prevent negative inventory.
- Use FEFO for batch consumption.
- Use scaled integers for quantities.
- Store date-only expiry values as `YYYY-MM-DD`.
- Validate household ownership in every cloud function.
- Add tests for domain logic before declaring a milestone complete.
- Maintain a runnable project after every commit.
- Document configuration and manual setup in README.
