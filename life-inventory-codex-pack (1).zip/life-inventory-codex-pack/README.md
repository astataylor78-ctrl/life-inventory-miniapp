# 生活物品管家开发包

这是一个用于交给 Codex 开发的仓库准备包。

## 文件
- `PRD.md`：完整产品需求
- `CODEX_TASK.md`：Codex 执行任务书
- `TECHNICAL_PLAN.md`：技术和架构要求
- `ACCEPTANCE_TESTS.md`：验收测试
- `AGENTS.md`：仓库内智能开发代理规则

## 建议流程
1. 在 GitHub 新建一个空仓库，例如 `life-inventory-miniapp`。
2. 将本目录文件提交到默认分支。
3. 在 Codex 中选择该仓库。
4. 将 `CODEX_TASK.md` 作为首个任务。
5. 要求 Codex 先完成 Milestone 1，并创建草稿 PR。
6. 验收通过后再继续后续 Milestone。

## 产品形态
第一版为微信小程序。技术栈为 uni-app + Vue 3 + TypeScript + 微信云开发。
