# 技术实施方案

## 1. 总体方案

采用 uni-app + Vue 3 + TypeScript 开发微信小程序，使用微信云开发作为后端。

```text
微信小程序
  ├── 页面与组件
  ├── Pinia 状态
  ├── Domain 纯业务逻辑
  └── Service API
        ↓
微信云函数
  ├── 身份和权限校验
  ├── 参数校验
  ├── 事务
  └── 数据库/云存储
```

## 2. 数据一致性

库存变化必须在云函数中执行，禁止前端先修改数据库再补流水。

一次库存操作包括：
1. 校验用户和 household。
2. 读取物品和批次。
3. 计算批次扣减或增加方案。
4. 写入批次数量。
5. 写入物品总数量。
6. 写入流水。
7. 事务提交。

## 3. 数量精度

前端允许最多 3 位小数。数据库存储为放大 1000 倍的整数：
- 1 个 -> 1000
- 0.5 瓶 -> 500
- 1.125 kg -> 1125

服务层负责显示值和存储值转换，避免浮点误差。

## 4. 日期

保质期只存储 `YYYY-MM-DD`，不存储带时区时间戳。
业务计算使用用户本地日期，并通过统一工具进行比较。
`created_at`、`updated_at` 使用数据库服务端时间。

## 5. 权限

云函数从登录上下文获取 openid：
- 查询 user
- 查询 household.owner_user_id
- 校验资源 household_id
- 所有查询强制带 household_id

不要接受前端提交的 owner_user_id。

## 6. 索引建议

- users.openid 唯一索引
- items: household_id + updated_at
- items: household_id + category_id
- items: household_id + location_id
- item_batches: item_id + effective_expiration_date
- inventory_transactions: item_id + created_at
- categories: household_id + is_active
- locations: household_id + parent_id

## 7. 云函数

### auth-init
首次登录初始化用户、家庭空间、默认分类和默认设置。

### items
物品 CRUD、搜索、分页、筛选、图片引用管理。

### inventory
库存增加、扣减、用完、调整、丢弃和新购入。

### expiry-reminder
每日扫描，生成提醒候选；发送前检查订阅权限和去重。

### export-data
生成 JSON/CSV，返回临时下载地址。

## 8. 测试重点

- 有效期早的批次优先扣减。
- 不能扣成负数。
- 目标库存小于安全库存时拒绝。
- 开封到期早于包装到期时选开封到期。
- 过期批次状态边界。
- 跨月和闰年日期。
- 并发扣减。
- 非所有者访问被拒绝。
